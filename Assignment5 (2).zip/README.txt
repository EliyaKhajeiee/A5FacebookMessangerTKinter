This is a multipart project that consistnt of being able to send a message to a user, be able to retrieve messages that are new, and recieve
messages are that all from the user. The main part of the code is the GUI which is an interface that allows the user to create or load
a dsu profile. Then they are able to talk to other dsu file members through the server. It consistently checks for new messages and appends
them to the profile to store locally, the GUI has different widgets with different colors to distinguish from other students. The problem 
with the code is that you aren't able to change your username or password. 