import unittest
import json
from ds_protocol import extract_json, DataTuple
from ds_protocol import ds_prot
#python -m unittest test_ds_protocol
#python -m coverage run -m unittest test_ds_protocol
#python -m coverage report

class DS_test(unittest.TestCase):

    def test_valid_json(self):
        json_msg = '{"response": {"type": "ok", "message": "Welcome back, Eliya", "token": "bb3fb3ad-1029-4aa8-80f8-55cf0fb9066a"}}'
        expected_result = DataTuple(response={"type": "ok", "message": "Welcome back, Eliya", "token": "bb3fb3ad-1029-4aa8-80f8-55cf0fb9066a"}, server_type="ok")
        self.assertEqual(extract_json(json_msg), expected_result)

    def test_key_error(self):
        json_msg = '{"response": {"message": "Welcome back, Eliya", "token": "bb3fb3ad-1029-4aa8-80f8-55cf0fb9066a"}, "server_type": "ok"}'
        assert extract_json(json_msg) == None

    def test_not_valid(self):
        json_msg = 'ASUDNASJNDIASNBDA'
        expected_result = None
        self.assertEqual(extract_json(json_msg),expected_result)

    def test_directmessage(self):
        message = "test message"
        recipient = "arit"
        ds = ds_prot(username="Eliya", password="Khajeie")
        s_response = ds.joinserver()
        response = ds.directmessage(message, recipient)
        extract_response = extract_json(response)
        actual_output = extract_response.response
        expected_output = {'type': 'ok', 'message': 'Direct message sent'}
        self.assertEqual(actual_output, expected_output)

    def test_all_messages(self):
        token = "bb3fb3ad-1029-4aa8-80f8-55cf0fb9066a"
        message = "all"
        ds = ds_prot(username="Eliya", password="Khajeie")
        s_response = ds.joinserver()
        expected_output = {'token': token, 'directmessage': 'all'}
        actual_output = ds.directmessage(message, recipient="Eliya")
        self.assertEqual(actual_output, expected_output)