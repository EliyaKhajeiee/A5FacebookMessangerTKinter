import socket 
import json
from ds_protocol import extract_json
import time
from Profile import Profile

port = 3021


class DirectMessage:
  def __init__(self):
    self.recipient = None
    self.message = None
    self.timestamp = None


class DirectMessenger:
    def __init__(self, dsuserver='168.235.86.101', username=None, password=None):
        self.token = None
        self.username = username
        self.password = password
        self.dsuserver = dsuserver
		
    def joinserver(self):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
                srv.connect((self.dsuserver, port))
                server_msg_join = {"join": {"username": self.username, "password": self.password, "token": ""}}
                srv.sendall(json.dumps(server_msg_join).encode('utf-8')) #if join, gives back token 
                s_response = srv.recv(1024).decode('utf-8')
                return s_response
        
    def send(self, message:str, recipient:str) -> bool:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
                srv.connect((self.dsuserver, port))
                server_msg_join = {"join": {"username": self.username, "password": self.password, "token": ""}}
                srv.sendall(json.dumps(server_msg_join).encode('utf-8'))
                s_response = srv.recv(1024).decode('utf-8')
                try:
                    extract_response = extract_json(s_response)
                    response = extract_response[0]
                    token = response['token']
                except KeyError or TypeError:
                    extract_response = extract_json(s_response)
                    response = extract_response[0]
                    return False

                dm_msg = {"token": token, "directmessage": {"entry": message, "recipient": recipient, "timestamp": time.time()}}
                srv.sendall(json.dumps(dm_msg).encode('utf-8'))
                response = srv.recv(1024).decode('utf-8')
                response_dict = json.loads(response)
                return True
        except socket.error as e:
            print(f"Error: {e}")
            return False

            
    def retrieve_new(self) -> list:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
                srv.connect((self.dsuserver, port))
                server_msg_join = {"join": {"username": self.username, "password": self.password, "token": ""}}
                srv.sendall(json.dumps(server_msg_join).encode('utf-8')) #if join, gives back token 
                s_response = srv.recv(1024).decode('utf-8') #welcome back USER 
                try:
                    extract_response = extract_json(s_response)
                    response = extract_response[0]
                    token = response['token']
                except KeyError or TypeError:
                    extract_response = extract_json(s_response)
                    response = extract_response[0]
                    res = response['message']
                    return []
                direct_msg = {
                    "token": token,
                    "directmessage": "new"
                }
                srv.sendall(json.dumps(direct_msg).encode('utf-8'))
                response = srv.recv(16328).decode('utf-8')
                extract_response = extract_json(response)
                res_dict = json.loads(response)
                new_messages = []
                for msg in res_dict['response']['messages']:
                    new_messages.append(msg['message'])
                return new_messages
        except socket.error as e:
            print(f"Failed to connect to server: {e}")
            print("Remember, you have to have the right DSU IP in order to connect to the server!")
            return False

    def retrieve_all(self) -> list:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
                srv.connect((self.dsuserver, port))
                server_msg_join = {"join": {"username": self.username, "password": self.password, "token": ""}}
                srv.sendall(json.dumps(server_msg_join).encode('utf-8')) #if join, gives back token 
                s_response = srv.recv(1024).decode('utf-8')
                try:
                    extract_response = extract_json(s_response)
                    response = extract_response[0]
                    token = response['token']
                except KeyError or TypeError:
                    extract_response = extract_json(s_response)
                    response = extract_response[0]
                    res = response['message']
                    return []
                direct_msg = {
                    "token": token,
                    "directmessage": "all"
                }
                srv.sendall(json.dumps(direct_msg).encode('utf-8'))
                response = srv.recv(16328).decode('utf-8')
                extract_response = extract_json(response)
                res_dict = json.loads(response)
                all_messages = []
                for msg in res_dict['response']['messages']: #maybe change this if server cant be figured out 
                    all_messages.append(msg['message'])
                return all_messages
        except socket.error as e:
            print(f"Failed to connect to server: {e}")
            print("Remember, you have to have the right DSU IP in order to connect to the server!")

    def retrieve_all_useful(self) -> list:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
                srv.connect((self.dsuserver, port))
                server_msg_join = {"join": {"username": self.username, "password": self.password, "token": ""}}
                srv.sendall(json.dumps(server_msg_join).encode('utf-8')) #if join, gives back token 
                s_response = srv.recv(1024).decode('utf-8')
                try:
                    extract_response = extract_json(s_response)
                    response = extract_response[0]
                    token = response['token']
                except KeyError or TypeError:
                    extract_response = extract_json(s_response)
                    response = extract_response[0]
                    res = response['message']
                    return []
                direct_msg = {
                    "token": token,
                    "directmessage": "all"
                }
                srv.sendall(json.dumps(direct_msg).encode('utf-8'))
                response = srv.recv(16328).decode('utf-8')
                extract_response = extract_json(response)
                res_dict = json.loads(response)
            messages_list = []
            for msg in res_dict['response']['messages']:
                message_dict = {"message": msg['message'], "from": msg['from'], "timestamp": msg['timestamp']}
                messages_list.append(message_dict)
            return messages_list
        except socket.error as e:
            print(f"Failed to connect to server: {e}")
            print("Remember, you have to have the right DSU IP in order to connect to the server!")


    def retrieve_new_useful(self) -> list:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
                srv.connect((self.dsuserver, port))
                server_msg_join = {"join": {"username": self.username, "password": self.password, "token": ""}}
                srv.sendall(json.dumps(server_msg_join).encode('utf-8')) #if join, gives back token 
                s_response = srv.recv(1024).decode('utf-8') #welcome back USER 
                try:
                    extract_response = extract_json(s_response)
                    response = extract_response[0]
                    token = response['token']
                except KeyError or TypeError:
                    extract_response = extract_json(s_response)
                    response = extract_response[0]
                    res = response['message']
                    return []
                direct_msg = {
                    "token": token,
                    "directmessage": "new"
                }
                srv.sendall(json.dumps(direct_msg).encode('utf-8'))
                response = srv.recv(16328).decode('utf-8')
                extract_response = extract_json(response)
                res_dict = json.loads(response)
            messages_list = []
            for msg in res_dict['response']['messages']:
                message_dict = {"message": msg['message'], "from": msg['from'], "timestamp": msg['timestamp']}
                messages_list.append(message_dict)
            return messages_list
        except socket.error as e:
            print(f"Failed to connect to server: {e}")
            print("Remember, you have to have the right DSU IP in order to connect to the server!")
            return False
dm = DirectMessenger(dsuserver='168.235.86.101', username="Eliya", password="Khajeie")
#all_messages = dm.retrieve_all()
#new_messages = dm.retrieve_new()
#all_useful = dm.retrieve_all_useful()
#new_useful = dm.retrieve_new_useful()
#print(all_messages,"AM")
#print(new_messages,"NM")
#print(all_useful,"UF")
#print(new_useful,"NFY")
#(dm.send("hi friends pet pet pet","Eliya"))
#print(dm.joinserver())



