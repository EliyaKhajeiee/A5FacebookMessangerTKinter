import unittest
import ds_messenger
#python -m unittest test_ds_messenger
#python -m coverage run -m unittest test_ds_messenger
#python -m coverage report
class DMTest(unittest.TestCase):
    def setUp(self):
        self.server = '168.235.86.101'
        self.port = 3021
        self.username = 'Eliya'
        self.password = 'Khajeie'
        self.recipient = 'Eliya'
        self.dm = ds_messenger.DirectMessenger(self.server, self.username, self.password)
        self.dm.joinserver()
        self.recipient = 'Eliya'
    

    def test_init(self):
        dm = ds_messenger.DirectMessage()
        self.assertIsNone(dm.recipient)
        self.assertIsNone(dm.message)
        self.assertIsNone(dm.timestamp)
    
    def test_check_join(self):
        a = self.dm.joinserver()
        self.assertEqual(a.rstrip(), '{"response": {"type": "ok", "message": "Welcome back, Eliya", "token": "bb3fb3ad-1029-4aa8-80f8-55cf0fb9066a"}}')

    def test_check_send(self):
        a = self.dm.send("TestMSG", self.recipient)
        self.assertTrue(a)

    def test_check_retrieve_new(self):
        existing_messages = self.dm.retrieve_new()
        messages = ["hi","test1"]
        for message in messages:
            self.dm.send(message, self.recipient)
        new_messages = self.dm.retrieve_new()
        self.assertIsInstance(new_messages, list)
        all_messages = existing_messages + new_messages
        for message in messages:
            self.assertIn(message, all_messages)

    def test_retrieve_all(self):
        retrieveall = self.dm.retrieve_all()
        assert type(retrieveall) == list

    def test_retrieve_all_use(self):
        retrieveall = self.dm.retrieve_all_useful()
        assert type(retrieveall) == list

    def test_retrieve_new_use(self):
        retrieveall = self.dm.retrieve_new_useful()
        assert type(retrieveall) == list

    def test_send_keyerror(self):
        dm = ds_messenger.DirectMessenger("168.235.86.12893h19283u21893u129321893123", "389haiusbdiuasbdusiabda", "oajsndjoasbdbjasbd")
        result = dm.send({"entry": "wrongwrongwrong!"}, "ijasbndasjbdsiajbdiabdashdbsahbd")
        self.assertFalse(result)

    def test_retrievenew_keyerror(self):
        dm = ds_messenger.DirectMessenger("168.235.86.12893h19283u21893u129321893123", "389haiusbdiuasbdusiabda", "oajsndjoasbdbjasbd")
        result = dm.retrieve_new()
        self.assertFalse(result)


    def test_retrievenewuseful_keyerror(self):
        dm = ds_messenger.DirectMessenger("168.235.86.12893h19283u21893u129321893123", "389haiusbdiuasbdusiabda", "oajsndjoasbdbjasbd")
        result = dm.retrieve_new_useful()
        self.assertFalse(result)


    def test_retrieveall_keyerror(self):
        dm = ds_messenger.DirectMessenger("168.235.86.12893h19283u21893u129321893123", "389haiusbdiuasbdusiabda", "oajsndjoasbdbjasbd")
        result = dm.retrieve_all()
        self.assertFalse(result)

    def test_retrievealluseful_keyerror(self):
        dm = ds_messenger.DirectMessenger("168.235.86.12893h19283u21893u129321893123", "389haiusbdiuasbdusiabda", "oajsndjoasbdbjasbd")
        result = dm.retrieve_all_useful()
        self.assertFalse(result)

