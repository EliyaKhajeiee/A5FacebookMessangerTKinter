# ds_protocol.py

# Starter code for assignment 3 in ICS 32 Programming with Software Libraries in Python

# Replace the following placeholders with your information.

# Eliya Khajeie
# ekhajeie@uci.edu
# 85362437

import json 
from collections import namedtuple
import time
import socket
import json
import time

DataTuple = namedtuple('DataTuple', ['response', 'server_type'])

def extract_json(json_msg: str) -> DataTuple:
    try:
        json_obj = json.loads(json_msg)
        response = json_obj['response']
        server_type = json_obj['response']['type']
    except json.JSONDecodeError:
        print("Json cannot be decoded.")
        return None
    except KeyError as e:
        print(f'Missing key in JSON message : {e}')
        return None

    return DataTuple(response, server_type)

class ds_prot:
    def __init__(self, username=None, password=None,dsuserver='168.235.86.101'):
        self.token = None
        self.username = username
        self.password = password
        self.dsuserver = dsuserver
        self.port = 3021

    def joinserver(self):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
                srv.connect((self.dsuserver, self.port))
                server_msg_join = {"join": {"username": self.username, "password": self.password, "token": ""}}
                srv.sendall(json.dumps(server_msg_join).encode('utf-8')) #if join, gives back token 
                s_response = srv.recv(1024).decode('utf-8')
                return s_response
        

    def directmessage(self,message,recipient):
        s_response = self.joinserver()
        extract_response = extract_json(s_response)
        response = extract_response[0] #full server response 
        token = response['token']
        if message == "new": #to see new messages 
            msg_to_server = {
                "token": token,
                "directmessage": "new"
            }
        elif message == "all": #to see all messages 
            msg_to_server = {
                "token": token,
                "directmessage": "all"
            }
        else: #to normal send the message to someone 
            msg_to_server = {
                "token": token,
                "directmessage": {
                    "entry": message,
                    "recipient": recipient,
                    "timestamp": time.time()
                }
            }

        lst_msg = json.dumps(msg_to_server)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((self.dsuserver, self.port))
            # send message to server
            s.sendall(lst_msg.encode())
            response = s.recv(16328).decode()
            return (response)

            
